structure(list(
  url = "https://api.sleeper.app/v1/league/522458773317046272/drafts/",
  status_code = 200L, headers = structure(list(
    date = "Sat, 14 Nov 2020 16:45:56 GMT",
    `content-type` = "application/json; charset=utf-8", vary = "Accept-Encoding",
    `cache-control` = "max-age=0, private, must-revalidate",
    `x-request-id` = "a2b3f91f0a5d9c4c81889ceb6e6c807b",
    `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
    `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
    `content-encoding` = "gzip", `cf-cache-status` = "MISS",
    `cf-request-id` = "06693f3ebc0000ecf653b63000000001",
    `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
    server = "cloudflare", `cf-ray` = "5f2234aacb54ecf6-YUL"
  ), class = c(
    "insensitive",
    "list"
  )), all_headers = list(list(
    status = 200L, version = "HTTP/2",
    headers = structure(list(
      date = "Sat, 14 Nov 2020 16:45:56 GMT",
      `content-type` = "application/json; charset=utf-8",
      vary = "Accept-Encoding", `cache-control` = "max-age=0, private, must-revalidate",
      `x-request-id` = "a2b3f91f0a5d9c4c81889ceb6e6c807b",
      `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
      `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
      `content-encoding` = "gzip", `cf-cache-status` = "MISS",
      `cf-request-id` = "06693f3ebc0000ecf653b63000000001",
      `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
      server = "cloudflare", `cf-ray` = "5f2234aacb54ecf6-YUL"
    ), class = c(
      "insensitive",
      "list"
    ))
  )), cookies = structure(list(
    domain = "#HttpOnly_.sleeper.app",
    flag = TRUE, path = "/", secure = TRUE, expiration = structure(1607964221, class = c(
      "POSIXct",
      "POSIXt"
    )), name = "__cfduid", value = "REDACTED"
  ), row.names = c(
    NA,
    -1L
  ), class = "data.frame"), content = charToRaw("[{\"type\":\"linear\",\"status\":\"complete\",\"start_time\":1587906296857,\"sport\":\"nfl\",\"settings\":{\"teams\":12,\"slots_wr\":2,\"slots_te\":1,\"slots_rb\":2,\"slots_qb\":1,\"slots_flex\":2,\"slots_bn\":27,\"rounds\":4,\"player_type\":1,\"pick_timer\":28800,\"cpu_autopick\":0,\"alpha_sort\":0},\"season_type\":\"regular\",\"season\":\"2020\",\"metadata\":{\"slot_name_9\":\"CJS\",\"slot_name_8\":\"Don\",\"slot_name_7\":\"Gabe\",\"slot_name_6\":\"BLANK\",\"slot_name_5\":\"CJS\",\"slot_name_4\":\"Gabe\",\"slot_name_3\":\"Alex\",\"slot_name_2\":\"Brian\",\"slot_name_12\":\"BLANK\",\"slot_name_11\":\"Travis\",\"slot_name_10\":\"Brian\",\"slot_name_1\":\"Justin\",\"scoring_type\":\"dynasty\",\"name\":\"The JanMichaelLarkin Dynasty League\",\"description\":\"\"},\"league_id\":\"522458773317046272\",\"last_picked\":1588025835239,\"last_message_time\":1588025835489,\"last_message_id\":\"560624623687753728\",\"draft_order\":{\"76686532077305856\":4,\"70729037081100288\":12,\"409797051455393792\":2,\"401485903224193024\":8,\"387070108625039360\":6,\"386976568364306432\":1,\"386950378371207168\":7,\"386571720443764736\":10,\"386383436639973376\":9,\"202892038360801280\":11,\"202882046337490944\":5,\"198540145396289536\":3},\"draft_id\":\"522458773321240576\",\"creators\":[\"386571720443764736\"],\"created\":1578926387675}]"),
  date = structure(1605372356, class = c("POSIXct", "POSIXt"), tzone = "GMT"), times = c(
    redirect = 0, namelookup = 4.8e-05,
    connect = 5.3e-05, pretransfer = 0.000144, starttransfer = 0.331311,
    total = 0.331388
  )
), class = "response")
