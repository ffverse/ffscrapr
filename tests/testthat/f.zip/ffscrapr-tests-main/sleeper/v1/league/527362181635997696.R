structure(list(
  url = "https://api.sleeper.app/v1/league/527362181635997696/",
  status_code = 404L, headers = structure(list(
    date = "Thu, 08 Oct 2020 12:18:43 GMT",
    `content-type` = "application/json; charset=utf-8", `content-length` = "4",
    connection = "keep-alive", `cache-control` = "max-age=0, private, must-revalidate",
    `x-request-id` = "d2d30a97b644024093a988710832c34a",
    `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
    `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
    `cf-cache-status` = "MISS", `cf-request-id` = "05a9bf4cc60000ecaf7b197200000001",
    `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
    vary = "Accept-Encoding", server = "cloudflare", `cf-ray` = "5defce5add72ecaf-DFW"
  ), class = c(
    "insensitive",
    "list"
  )), all_headers = list(list(
    status = 404L, version = "HTTP/1.1",
    headers = structure(list(
      date = "Thu, 08 Oct 2020 12:18:43 GMT",
      `content-type` = "application/json; charset=utf-8",
      `content-length` = "4", connection = "keep-alive",
      `cache-control` = "max-age=0, private, must-revalidate",
      `x-request-id` = "d2d30a97b644024093a988710832c34a",
      `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
      `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
      `cf-cache-status` = "MISS", `cf-request-id` = "05a9bf4cc60000ecaf7b197200000001",
      `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
      vary = "Accept-Encoding", server = "cloudflare",
      `cf-ray` = "5defce5add72ecaf-DFW"
    ), class = c(
      "insensitive",
      "list"
    ))
  )), cookies = structure(list(
    domain = "#HttpOnly_.sleeper.app",
    flag = TRUE, path = "/", secure = TRUE, expiration = structure(1604620002, class = c(
      "POSIXct",
      "POSIXt"
    )), name = "__cfduid", value = "REDACTED"
  ), row.names = c(
    NA,
    -1L
  ), class = "data.frame"), content = charToRaw("null"),
  date = structure(1602159523, class = c("POSIXct", "POSIXt"), tzone = "GMT"), times = c(
    redirect = 0, namelookup = 7e-05,
    connect = 7.2e-05, pretransfer = 0.000171, starttransfer = 0.138846,
    total = 0.138875
  )
), class = "response")
