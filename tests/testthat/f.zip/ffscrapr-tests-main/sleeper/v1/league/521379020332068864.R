structure(list(
  url = "https://api.sleeper.app/v1/league/521379020332068864/",
  status_code = 200L, headers = structure(list(
    date = "Tue, 13 Oct 2020 01:45:17 GMT",
    `content-type` = "application/json; charset=utf-8", vary = "Accept-Encoding",
    `cache-control` = "max-age=0, private, must-revalidate",
    `x-request-id` = "3a8ec8f235282915bb19ab12c0a72c22",
    `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
    `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
    `content-encoding` = "gzip", `cf-cache-status` = "MISS",
    `cf-request-id` = "05c13b2af60000ca6f41b69200000001",
    `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
    server = "cloudflare", `cf-ray` = "5e156157fe62ca6f-YUL"
  ), class = c(
    "insensitive",
    "list"
  )), all_headers = list(list(
    status = 200L, version = "HTTP/2",
    headers = structure(list(
      date = "Tue, 13 Oct 2020 01:45:17 GMT",
      `content-type` = "application/json; charset=utf-8",
      vary = "Accept-Encoding", `cache-control` = "max-age=0, private, must-revalidate",
      `x-request-id` = "3a8ec8f235282915bb19ab12c0a72c22",
      `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
      `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
      `content-encoding` = "gzip", `cf-cache-status` = "MISS",
      `cf-request-id` = "05c13b2af60000ca6f41b69200000001",
      `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
      server = "cloudflare", `cf-ray` = "5e156157fe62ca6f-YUL"
    ), class = c(
      "insensitive",
      "list"
    ))
  )), cookies = structure(list(
    domain = "#HttpOnly_.sleeper.app",
    flag = TRUE, path = "/", secure = TRUE, expiration = structure(1605145349, class = c(
      "POSIXct",
      "POSIXt"
    )), name = "__cfduid", value = "REDACTED"
  ), row.names = c(
    NA,
    -1L
  ), class = "data.frame"), content = charToRaw("{\"total_rosters\":12,\"status\":\"in_season\",\"sport\":\"nfl\",\"shard\":332,\"settings\":{\"max_keepers\":1,\"draft_rounds\":4,\"trade_review_days\":0,\"reserve_allow_dnr\":1,\"capacity_override\":1,\"pick_trading\":1,\"taxi_years\":1,\"taxi_allow_vets\":0,\"last_report\":4,\"disable_adds\":0,\"waiver_type\":2,\"bench_lock\":0,\"reserve_allow_sus\":1,\"type\":2,\"reserve_allow_cov\":1,\"waiver_clear_days\":2,\"daily_waivers_last_ran\":12,\"waiver_day_of_week\":2,\"start_week\":1,\"playoff_teams\":4,\"num_teams\":12,\"reserve_slots\":10,\"playoff_round_type\":2,\"daily_waivers_hour\":0,\"waiver_budget\":200,\"reserve_allow_out\":1,\"offseason_adds\":1,\"last_scored_leg\":4,\"playoff_seed_type\":0,\"daily_waivers\":1,\"playoff_week_start\":14,\"daily_waivers_days\":567,\"league_average_match\":0,\"leg\":5,\"trade_deadline\":13,\"reserve_allow_doubtful\":0,\"taxi_deadline\":4,\"reserve_allow_na\":0,\"taxi_slots\":5,\"playoff_type\":0},\"season_type\":\"regular\",\"season\":\"2020\",\"scoring_settings\":{\"pass_2pt\":2.0,\"pass_int\":-1.0,\"fgmiss\":-1.0,\"rec_yd\":0.10000000149011612,\"xpmiss\":-1.0,\"fgm_30_39\":3.0,\"blk_kick\":2.0,\"pts_allow_7_13\":4.0,\"ff\":1.0,\"fgm_20_29\":3.0,\"fgm_40_49\":4.0,\"pts_allow_1_6\":7.0,\"st_fum_rec\":1.0,\"def_st_ff\":1.0,\"st_ff\":1.0,\"pts_allow_28_34\":-1.0,\"fgm_50p\":5.0,\"fum_rec\":2.0,\"def_td\":6.0,\"fgm_0_19\":3.0,\"int\":2.0,\"pts_allow_0\":10.0,\"pts_allow_21_27\":0.0,\"rec_2pt\":2.0,\"rec\":0.5,\"xpm\":1.0,\"st_td\":6.0,\"def_st_fum_rec\":1.0,\"def_st_td\":6.0,\"sack\":1.0,\"rush_2pt\":2.0,\"rec_td\":6.0,\"pts_allow_35p\":-4.0,\"pts_allow_14_20\":1.0,\"rush_yd\":0.10000000149011612,\"pass_yd\":0.03999999910593033,\"pass_td\":4.0,\"rush_td\":6.0,\"fum_lost\":-2.0,\"fum\":-1.0,\"safe\":2.0},\"roster_positions\":[\"QB\",\"RB\",\"RB\",\"WR\",\"WR\",\"WR\",\"TE\",\"FLEX\",\"FLEX\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\",\"BN\"],\"previous_league_id\":\"464109311174373376\",\"name\":\"DLP Dynasty League\",\"metadata\":null,\"loser_bracket_id\":null,\"league_id\":\"521379020332068864\",\"last_read_id\":null,\"last_pinned_message_id\":null,\"last_message_time\":1602511717292,\"last_message_text_map\":{},\"last_message_text\":\"well there&apos;s always next season guys rip the fantasy\",\"last_message_id\":\"621382815673585664\",\"last_message_attachment\":null,\"last_author_is_bot\":false,\"last_author_id\":\"589594433561858048\",\"last_author_display_name\":\"Conquistador00\",\"last_author_avatar\":null,\"group_id\":null,\"draft_id\":\"521379020332068865\",\"company_id\":null,\"bracket_id\":null,\"avatar\":null}"),
  date = structure(1602553517, class = c("POSIXct", "POSIXt"), tzone = "GMT"), times = c(
    redirect = 0, namelookup = 3.7e-05,
    connect = 4.1e-05, pretransfer = 0.000146, starttransfer = 0.322427,
    total = 0.32252
  )
), class = "response")
