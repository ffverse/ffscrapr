structure(list(
  url = "https://api.sleeper.app/v1/league/598598956691288064/users",
  status_code = 200L, headers = structure(list(
    date = "Thu, 13 Aug 2020 13:30:36 GMT",
    `content-type` = "application/json; charset=utf-8", vary = "Accept-Encoding",
    `cache-control` = "max-age=0, private, must-revalidate",
    `x-request-id` = "c90b3f7910fd70560af414603243f843",
    `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
    `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
    `content-encoding` = "gzip", `cf-cache-status` = "BYPASS",
    `cf-request-id` = "04899cfdbd0000ca4b7d937200000001",
    `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
    server = "cloudflare", `cf-ray` = "5c22caa92aabca4b-YUL"
  ), class = c(
    "insensitive",
    "list"
  )), all_headers = list(list(
    status = 200L, version = "HTTP/2",
    headers = structure(list(
      date = "Thu, 13 Aug 2020 13:30:36 GMT",
      `content-type` = "application/json; charset=utf-8",
      vary = "Accept-Encoding", `cache-control` = "max-age=0, private, must-revalidate",
      `x-request-id` = "c90b3f7910fd70560af414603243f843",
      `access-control-allow-origin` = "*", `access-control-expose-headers` = "etag",
      `access-control-allow-credentials` = "true", `strict-transport-security` = "max-age=15724800; includeSubDomains",
      `content-encoding` = "gzip", `cf-cache-status` = "BYPASS",
      `cf-request-id` = "04899cfdbd0000ca4b7d937200000001",
      `expect-ct` = "max-age=604800, report-uri=\"https://report-uri.cloudflare.com/cdn-cgi/beacon/expect-ct\"",
      server = "cloudflare", `cf-ray` = "5c22caa92aabca4b-YUL"
    ), class = c(
      "insensitive",
      "list"
    ))
  )), cookies = structure(list(
    domain = "#HttpOnly_.sleeper.app",
    flag = TRUE, path = "/", secure = TRUE, expiration = structure(1599917339, class = c(
      "POSIXct",
      "POSIXt"
    )), name = "__cfduid", value = "REDACTED"
  ), row.names = c(
    NA,
    -1L
  ), class = "data.frame"), content = charToRaw("[{\"user_id\":\"202892038360801280\",\"settings\":null,\"metadata\":{\"mention_pn\":\"on\",\"allow_pn\":\"on\"},\"league_id\":\"598598956691288064\",\"is_owner\":null,\"is_bot\":false,\"display_name\":\"solarpool\",\"avatar\":\"a71f864896ba28cbfaa4dc5df5b564e0\"},{\"user_id\":\"464108705281994752\",\"settings\":null,\"metadata\":{\"mention_pn\":\"on\",\"allow_pn\":\"on\"},\"league_id\":\"598598956691288064\",\"is_owner\":null,\"is_bot\":false,\"display_name\":\"silentclock\",\"avatar\":null},{\"user_id\":\"464123755250053120\",\"settings\":null,\"metadata\":{\"mention_pn\":\"on\",\"allow_pn\":\"on\"},\"league_id\":\"598598956691288064\",\"is_owner\":true,\"is_bot\":false,\"display_name\":\"Rah292\",\"avatar\":\"6f925123e8c7894bf1cddb0e21a9ae71\"}]"),
  date = structure(1597325436, class = c("POSIXct", "POSIXt"), tzone = "GMT"), times = c(
    redirect = 0, namelookup = 3.3e-05,
    connect = 3.6e-05, pretransfer = 0.000124, starttransfer = 0.045433,
    total = 0.045518
  )
), class = "response")
